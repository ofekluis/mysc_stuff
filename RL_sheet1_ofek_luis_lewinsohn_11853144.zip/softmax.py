import gym_bandits
import gym
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as st
import math

def epsilon_greedy(epsilon):
    rand = np.random.random()
    if rand < epsilon:
        action = env.action_space.sample()
    else:
        action = np.argmax(Q)
    return action

# number of rounds (iterations)
num_plays = 2000
num_experiments = 2001
arms = 10

## interactive plotting on (no need to close window for next iteration)
plt.ion()
plt.figure(figsize=(20,10))

#######################
# conduct experiment
#######################
# memorize all rewards of all episodes in rewardMemory for statistic plotting
decay = 1e-10
tau =0.2
meanLst=[]
stdLst=[]
rewardMemoryLst=[]
x=np.arange(0.01,1.11,0.1)
for tau in np.arange(0.01,1.11,0.1):
    rewardMemory = []
    for e in range (1, num_experiments, 1):
        # create new instance of bandit environment
        env = gym.make("BanditTenArmedGaussian-v0")
        env.reset()

        # count of number of times an arm was pulled
        arm_count = np.zeros(arms)
        # Q value => expected average reward
        Q = np.zeros(arms)
        rewards = np.zeros(num_plays)
        for i in range (1, num_plays, 1):
            # choose arm according to max ucb
            sm_sum= sum(math.exp(Q[arm]/tau) for arm in range(arms))
            prob_arr = np.fromiter((math.exp(Q[arm]/tau)/sm_sum for arm in range(arms)),float)
            arm = np.random.choice(arms,1,p=prob_arr)[0]
            #arm = epsilon_greedy(epsilon)
            # get reward/observation/terminalInfo
            observation, reward, done, info = env.step(arm)
            # update the count of that arm
            arm_count[arm] += 1
            # recalculate its Q value
            Q[arm] = Q[arm]+ (1/arm_count[arm])*(reward-Q[arm])
            # memorize rewards per play
            rewards[i] = reward

        # memorize reward array
        rewardMemory.append(rewards)
    meanLst.append(np.mean(rewardMemory))
    stdLst.append(np.std(rewardMemory))
    ##################################################
    # Live plotting of statistics every 100 episodes
    ##################################################

ci = 0.95 # 95% confidence interval
means = np.array(meanLst)
stds = np.array(stdLst)
n = means.size

# compute upper/lower confidence bounds
test_stat = st.t.ppf((ci + 1) / 2, e)
lower_bound = means - test_stat * stds / np.sqrt(e)
upper_bound = means + test_stat * stds / np.sqrt(e)

#print ('Avg. Reward per step in experiment %d: %.4f' % (e, sum(means) / num_plays))

# clear plot frame
#plt.clf()

# plot average reward
plt.plot(x,means[np.argsort(x)] ,color='blue', label='Avg. Reward')#, label="tau=%.2f" % tau)

# plot upper/lower confidence bound
plt.fill_between(x=x, y1=lower_bound, y2=upper_bound, color='blue', alpha=0.2, label="CI %.2f" % ci)

plt.grid()
plt.xlim(0.01,1.01)
plt.ylim(0, 2) # limit y axis
plt.title('Avg. Reward after 2000 steps in 2000 experiments for different tau values using softmax')
plt.ylabel("Avg. Reward")
plt.xlabel("Tau")
plt.legend()
plt.show()
plt.pause(0.01)

## disable interactive plotting => otherwise window terminates
plt.ioff()
plt.show()
